import tensorflow as tf
import numpy as np
import sys
sys.path.append('../utils')
#sys.path.append('../vgg19')
from layer import *
#from vgg19 import VGG19
        
class SRGAN:
    def __init__(self, x, x_noise, is_training, batch_size):
        #if is_training:
        self.batch_size = batch_size
        self.downscaled = x_noise#self.downscale(x)
        self.imitation = self.generator(self.downscaled, is_training, False)
        self.g_loss= self.inference_losses(x, self.imitation)

    image_size = 24
    def generator(self, x, is_training, reuse):
        with tf.variable_scope('generator', reuse=reuse):
            #bic_ref = tf.image.resize_images(x, [self.image_size*4, self.image_size*4], method=2)
            with tf.variable_scope('de1'):
                x_de = conv_layer(x, [3, 3, 1, 32], 1)#96
                x_de = prelu(x_de)
            res0_in = x_de
            with tf.variable_scope('res0_0'):
                x_de = conv_layer(res0_in, [3, 3, 32, 32], 1)#96
                x_de = prelu(x_de)
            with tf.variable_scope('res0_1'):
                x_de = conv_layer(x_de, [3, 3, 32, 32], 1)#96
                x_de = prelu(x_de)
            res0_out = x_de + res0_in
            short0 = res0_out
            with tf.variable_scope('de2'):
                x_de = conv_layer(res0_out, [3, 3, 32, 64], 2)#48
                x_de = prelu(x_de)
            res1_in = x_de
            with tf.variable_scope('res1_0'):
                x_de = conv_layer(res1_in, [3, 3, 64, 64], 1)#48
                x_de = prelu(x_de)
            with tf.variable_scope('res1_1'):
                x_de = conv_layer(x_de, [3, 3, 64, 64], 1)#48
                x_de = prelu(x_de)
            res1_out = x_de + res1_in
            short1 = res1_out
            #x_de = max_pooling_layer(x_de, 2, 2)
            with tf.variable_scope('de3'):
                x_de = conv_layer(res1_out, [3, 3, 64, 128], 2)#24
                x_de = prelu(x_de)
            res2_in = x_de
            with tf.variable_scope('res2_0'):
                x_de = conv_layer(res2_in, [3, 3, 128, 128], 1)#48
                x_de = prelu(x_de)
            with tf.variable_scope('res2_1'):
                x_de = conv_layer(x_de, [3, 3, 128, 128], 1)#48
                x_de = prelu(x_de)
            res2_out = x_de + res2_in
            short2 = res2_out
            #x_de = max_pooling_layer(x_de, 2, 2)
            with tf.variable_scope('de4'):
                x_de = conv_layer(res2_out, [3, 3, 128, 256], 2)#12
                x_de = prelu(x_de)
            res3_in = x_de
            with tf.variable_scope('res3_0'):
                x_de = conv_layer(res3_in, [3, 3, 256, 256], 1)
                x_de = prelu(x_de)
            with tf.variable_scope('res3_1'):
                x_de = conv_layer(x_de, [3, 3, 256, 256], 1)
                x_de = prelu(x_de)
            res3_out = x_de + res3_in
            short3 = res3_out
            with tf.variable_scope('de4_1'):
                x_de = conv_layer(res3_out, [3, 3, 256, 64], 1)
                x_de = prelu(x_de)
            for i in range(9):#12
                with tf.variable_scope('block{}cnn1'.format(i+1)):
                    x1=x2=x3=x_de
                    for j in range(3):
                        with tf.variable_scope('block{}_{}cnn1'.format(i+1,j+1)):
                            with tf.variable_scope('ud1'):
                                a1 = prelu(deconv_layer(x1, [3, 3, 64, 64], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1))
                                #a1 = batch_normalize(a1, is_training)
                            with tf.variable_scope('ud2'):
                                b1 = prelu(deconv_layer(x2, [3, 3, 64, 64], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1))
                                #b1 = batch_normalize(b1, is_training)
                            with tf.variable_scope('ud3'):
                                c1 = prelu(deconv_layer(x3, [3, 3, 64, 64], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1))
                                #c1 = batch_normalize(c1, is_training)
                            sum = tf.concat([a1,b1,c1],3)
                            #sum = batch_normalize(sum, is_training)
                            with tf.variable_scope('ud4'):
                                sum1 = deconv_layer(sum, [1, 1, 64, 192], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1)
                                x1= prelu(sum1+x1)
								#x1 = batch_normalize(x1, is_training)tf.concat([sum,x1],3)
                            with tf.variable_scope('ud5'):
                                sum2 = deconv_layer(sum, [1, 1, 64, 192], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1)
                                x2= prelu(sum2+x2)
								#x2 = batch_normalize(x2, is_training)tf.concat([sum,x2],3)
                            with tf.variable_scope('ud6'):
                                sum3 = deconv_layer(sum, [1, 1, 64, 192], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1)
                                x3= prelu(sum3+x3)
								#x3 = batch_normalize(x3, is_training)tf.concat([sum,x3],3)
                    with tf.variable_scope('ud7'):
                        block_out = prelu(deconv_layer(tf.concat([x1, x2, x3],3), [3, 3, 64, 192], [self.batch_size, self.image_size//2, self.image_size//2, 64], 1))
                    #x = x1+x2+x3+x
                    x_de+=block_out
            with tf.variable_scope('de5_0'):
                x_de = deconv_layer(
                    x_de, [3, 3, 256, 64], [self.batch_size, self.image_size//2, self.image_size//2, 256], 1)
                x_de = prelu(x_de)# + short9#12
            res4_in = x_de + short3
            with tf.variable_scope('res4_0'):
                x_de = conv_layer(res4_in, [3, 3, 256, 256], 1)
                x_de = prelu(x_de)
            with tf.variable_scope('res4_1'):
                x_de = conv_layer(x_de, [3, 3, 256, 256], 1)
                x_de = prelu(x_de)
            res4_out = x_de + res4_in
            with tf.variable_scope('de5'):
                x_de = deconv_layer(
                    res4_out, [3, 3, 128, 256], [self.batch_size, self.image_size, self.image_size, 128], 2)
                x_de = prelu(x_de)# + short8#24
            res5_in = x_de + short2
            with tf.variable_scope('res5_0'):
                x_de = conv_layer(res5_in, [3, 3, 128, 128], 1)
                x_de = prelu(x_de)
            with tf.variable_scope('res5_1'):
                x_de = conv_layer(x_de, [3, 3, 128, 128], 1)
                x_de = prelu(x_de)
            res5_out = x_de + res5_in
            with tf.variable_scope('de6'):
                x_de = deconv_layer(
                    res5_out, [3, 3, 64, 128], [self.batch_size, self.image_size*2, self.image_size*2, 64], 2)
                x_de = prelu(x_de)# + short7#48
            res6_in = x_de + short1
            with tf.variable_scope('res6_0'):
                x_de = conv_layer(res6_in, [3, 3, 64, 64], 1)
                x_de = prelu(x_de)
            with tf.variable_scope('res6_1'):
                x_de = conv_layer(x_de, [3, 3, 64, 64], 1)
                x_de = prelu(x_de)
            res6_out = x_de + res6_in
            with tf.variable_scope('de7'):# res_in
                x_de = deconv_layer(
                    res6_out, [3, 3, 32, 64], [self.batch_size, self.image_size*4, self.image_size*4, 32], 2)
                x_de = prelu(x_de)# + short6#96
            res7_in = x_de + short0
            with tf.variable_scope('res7_0'):
                x_de = conv_layer(res7_in, [3, 3, 32, 32], 1)
                x_de = prelu(x_de)
            with tf.variable_scope('res7_1'):
                x_de = conv_layer(x_de, [3, 3, 32, 32], 1)
                x_de = prelu(x_de)
            res7_out = x_de + res7_in
            with tf.variable_scope('de8'):
                x_de = deconv_layer(
                    res7_out, [3, 3, 1, 32], [self.batch_size, self.image_size*4, self.image_size*4, 1], 1)
            x_DN = x - x_de
        self.g_variables = tf.get_collection(
            tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        return x_DN

    def downscale(self, x):
        K = 4
        arr = np.zeros([K, K, 3, 3])
        arr[:, :, 0, 0] = 1.0 / K ** 2
        arr[:, :, 1, 1] = 1.0 / K ** 2
        arr[:, :, 2, 2] = 1.0 / K ** 2
        weight = tf.constant(arr, dtype=tf.float32)
        downscaled = tf.nn.conv2d(
            x, weight, strides=[1, K, K, 1], padding='SAME')
        return downscaled


    def inference_losses(self, x, imitation):
			
        def inference_MSE_loss(x, imitation):
            loss = tf.reduce_mean(tf.sqrt((x - imitation) ** 2+(1e-3)**2))
            return tf.reduce_mean(loss)

        #content_loss = inference_content_loss(x, imitation)
        content_MSE_loss = inference_MSE_loss(x, imitation)
        #generator_loss, discriminator_loss = (inference_adversarial_loss(true_output, fake_output))
        #generator_loss, discriminator_loss = (inference_adversarial_loss_with_sigmoid(true_output, fake_output))
        g_loss = 1*content_MSE_loss#content_loss + 
        #d_loss = discriminator_loss
        return g_loss

