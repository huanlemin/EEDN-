import os
import numpy as np
import tensorflow as tf
import cv2
import matplotlib.pyplot as plt
from tqdm import tqdm
import sys
sys.path.append('../utils')
from layer import *
#from srgan import SRGAN
#from UDGANDN import SRGAN
from EERN import SRGAN
#from SRDenseNet import SRGAN 这个你都不注释德玛
import load
from PIL import Image
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

start_learning_rate = 2e-6# 2e-4, 5e-4
batch_size = 16
vgg_model = '../vgg19/backup/latest'

def train():
    x = tf.placeholder(tf.float32, [None, 96, 96, 1])#128,96
    x_noise = tf.placeholder(tf.float32, [None, 96, 96, 1])#128,96
    is_training = tf.placeholder(tf.bool, [])

    model = SRGAN(x, x_noise, is_training, batch_size)
    sess = tf.Session()
    with tf.variable_scope('srgan'):
        global_step = tf.Variable(0, name='global_step', trainable=False)
    #opt = tf.train.AdamOptimizer(learning_rate=start_learning_rate) #vdsr
    opt = tf.train.AdamOptimizer(learning_rate=tf.train.exponential_decay(start_learning_rate,global_step, 2000, decay_rate=0.8,staircase=False)+1e-6) #urdgn
    g_train_op = opt.minimize(model.all_loss, global_step=global_step, var_list=model.g_variables)
    #d_train_op = opt.minimize(model.d_loss, global_step=global_step, var_list=model.d_variables)
    init = tf.global_variables_initializer() 
    sess.run(init)

    # Restore the VGG-19 network
    # var = tf.global_variables()
    # vgg_var = [var_ for var_ in var if "vgg19" in var_.name]
    # saver = tf.train.Saver(vgg_var)
    # saver.restore(sess, vgg_model)

    if tf.train.get_checkpoint_state('EERN/'):
        saver = tf.train.Saver()
        saver.restore(sess, 'EERN/epoch30')

    # Load the data
    x_train, x_test, x_train_noise, x_test_noise = load.load()
    
    # Train the model
    n_iter = int(len(x_train) / batch_size)
    while True:
        #epoch = int(sess.run(global_step) / n_iter) + 1
        epoch = int(sess.run(global_step) / n_iter / 2) + 1
        print('epoch:', epoch)
        #np.random.shuffle(x_train)
        for i in tqdm(range(n_iter)):
            x_batch = normalize(x_train[i*batch_size:(i+1)*batch_size])
            x_batch_noise = normalize(x_train_noise[i*batch_size:(i+1)*batch_size])
            j = np.random.randint(0,8,size=1)
            x_batch = rotate(x_batch,j)
            x_batch_noise = rotate(x_batch_noise,j)#edge_loss, model.edge_loss
            all_loss, SSIM_loss, _ = sess.run([model.all_loss, model.SSIM_loss, g_train_op], feed_dict={x: x_batch, x_noise: x_batch_noise, is_training: True})
            format_str = ('epoch: %d, SSIM_loss: %.5f, all_loss: %.5f')
            print((format_str % (epoch, SSIM_loss, all_loss)))
        # Validate
        #raw = normalize(x_test[:batch_size])
        #raw = np.reshape(raw, (batch_size, 96, 96, 1))
        #raw_noise = normalize(x_test_noise[:batch_size])
        #raw_noise = np.reshape(raw_noise, (batch_size, 96, 96, 1))
        #fake = sess.run([model.imitation_dn], feed_dict={x: raw, x_noise: raw_noise, is_training: False})
        #print(noise.shape)
        #print(fake.shape)
        #print(raw.shape)
        #raw = np.squeeze(raw)
        #noise = np.squeeze(noise)
        #fake = np.squeeze(fake)
        #print(fake.shape)
        #save_img([raw_noise, fake, raw], ['Noise', 'Output', 'Ground Truth'], epoch)
        #print(fake.shape)
        # Save the model
        saver = tf.train.Saver()
        save_path = 'EERN'
        if epoch>0:
            #if epoch>0:
            #saver.save(sess, 'backup/latest', write_meta_graph=False)
            saver.save(sess, os.path.join(save_path, 'epoch{}'.format(epoch)), write_meta_graph=False)
            #save_img([raw_noise, fake, raw], ['Noise', 'Output', 'Ground Truth'], epoch)
        #saver.save(sess, 'backup/{0:04d}'.format(epoch), write_meta_graph=False)
        #saver.save(max_to_keep=50, keep_checkpoint_every_n_hours=1)
        #saver.save(sess, os.path.join(checkpoint_dir, model_name), global_step=step)
        #checkpoint_path = os.path.join(self.train_dir, 'checkpoints')
        #self.save(sess, checkpoint_path, step)

def save_img(imgs, label, epoch):
    for i in range(batch_size):
        fig = plt.figure()
        for j, img in enumerate(imgs):
            #im = np.uint8((img[i]+1)*127.5)
            #img[i] = Image.fromarray(img[i].astype('uint8')).convert('L')
            #noise = Image.fromarray(noise.astype('uint8')).convert('L')
            #fake = Image.fromarray(fake.astype('uint8')).convert('L')
            print(img.shape)
            image = np.clip((img[i]+1)*127.5, 0, 255).astype('uint8')
            print(image.shape)
            #img[i] = np.squeeze(img[i])
            #im = np.uint8(np.clip((img[i]+1)*127.5,0,255.0))
            im = Image.fromarray(image.astype('uint8')).convert('L')
            #im = Image.fromarray(img).convert('L')
            #im = np.uint8((np.clip(img[i],-1.0,1.0)+1)*127.5)
            #im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
            #im = im[160:340, 70:585, :]
            #im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
            fig.add_subplot(1, len(imgs), j+1)
            plt.imshow(im)
            plt.tick_params(labelbottom='off')
            plt.tick_params(labelleft='off')
            plt.gca().get_xaxis().set_ticks_position('none')
            plt.gca().get_yaxis().set_ticks_position('none')
            plt.xlabel(label[j])
        seq_ = "{0:09d}".format(i+1)
        epoch_ = "{0:09d}".format(epoch)
        path = os.path.join('result', seq_, '{}.png'.format(epoch_))
        if os.path.exists(os.path.join('result', seq_)) == False:
            os.mkdir(os.path.join('result', seq_))
        plt.savefig(path)
        plt.close()


def normalize(images):
    return np.array([image/127.5-1 for image in images])


if __name__ == '__main__':
    train()

