import tensorflow as tf
import numpy as np
import sys
sys.path.append('../utils')
#sys.path.append('../vgg19')
from layer import *
#from vgg19 import VGG19
from ssim_loss import *

class SRGAN:
    def __init__(self, x, x_noise, is_training, batch_size):
        self.batch_size = batch_size
        self.edge_enhance, self.base_dn, self.imitation_dn  = self.generator(x_noise, is_training, False)
        self.all_loss, self.SSIM_loss= self.inference_losses(x, self.base_dn, self.imitation_dn)
    image_size =  48#self.frame_hr, self.frame_sr,, self.g_frame_loss, self.d_frame_loss
    #image_size1 =  96self.real_base, self.fake_base,
    channels =  64
    def generator(self, x, is_training, reuse):
        with tf.variable_scope('generator', reuse=reuse):
            input = x
            with tf.variable_scope('conv1'):
                x = deconv_layer(
                    input, [3, 3, self.channels, 1], [self.batch_size, self.image_size*2, self.image_size*2, self.channels], 1)
                x = lrelu(x)
            with tf.variable_scope('down_1'):
                x_down = conv_layer(x, [3, 3, self.channels, self.channels], 2)#48
                x_down = lrelu(x_down)
            shortcut = x = x_down
            for i in range(5):
                with tf.variable_scope('block{}ex1'.format(i+1)):
                    x1=x2=x3=x
                    for j in range(3):
                        with tf.variable_scope('block{}_{}ex1'.format(i+1,j+1)):
                            with tf.variable_scope('ud1'):
                                a1 = lrelu(deconv_layer(x1, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #a1 = batch_normalize(a1, is_training)
                            with tf.variable_scope('ud2'):
                                b1 = lrelu(deconv_layer(x2, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #b1 = batch_normalize(b1, is_training)
                            with tf.variable_scope('ud3'):
                                c1 = lrelu(deconv_layer(x3, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #c1 = batch_normalize(c1, is_training)
                            sum = tf.concat([a1,b1,c1],3)
                            #sum = batch_normalize(sum, is_training)
                            with tf.variable_scope('ud4'):
                                x1 = lrelu(deconv_layer(tf.concat([sum,x1],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x1 = batch_normalize(x1, is_training)
                            with tf.variable_scope('ud5'):
                                x2 = lrelu(deconv_layer(tf.concat([sum,x2],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x2 = batch_normalize(x2, is_training)
                            with tf.variable_scope('ud6'):
                                x3 = lrelu(deconv_layer(tf.concat([sum,x3],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x3 = batch_normalize(x3, is_training)
                    with tf.variable_scope('ud7'):
                        block_out = lrelu(deconv_layer(tf.concat([x1, x2, x3],3), [3, 3, self.channels, self.channels*3], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                    #x = x1+x2+x3+x
                    x+=block_out
                    #x = batch_normalize(x, is_training))
                    
            #detail = x
            with tf.variable_scope('conv6'):
                x = deconv_layer(
                    x, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size*2, self.image_size*2, self.channels], 2)#2
                #x = pixel_shuffle_layerg(x, 2, self.channels//2) # n_split = 256 / 2 ** 2
                x = lrelu(x)
                
            with tf.variable_scope('conv8'):
                x_dn_base = deconv_layer(
                    x, [3, 3, 1, self.channels], [self.batch_size, self.image_size*2, self.image_size*2, 1], 1)

            
            # frame
            x_fa = self.Laplacian_single(x_dn_base) 
            with tf.variable_scope('conv_e1'):
                x_f = conv_layer(x_fa, [3, 3, 1, self.channels], 1)
                x_f = lrelu(x_f)
            with tf.variable_scope('conv_e3'):
                x_f = conv_layer(x_f, [3, 3, self.channels, self.channels], 2)
                x_f = lrelu(x_f)
            res_in = x_f
            # frame
            for i in range(3):
                with tf.variable_scope('block{}ex2'.format(i+1)):
                    x1=x2=x3=x_f
                    for j in range(3):
                        with tf.variable_scope('block{}_{}ex1'.format(i+1,j+1)):
                            with tf.variable_scope('ud1'):
                                a1 = lrelu(deconv_layer(x1, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #a1 = batch_normalize(a1, is_training)
                            with tf.variable_scope('ud2'):
                                b1 = lrelu(deconv_layer(x2, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #b1 = batch_normalize(b1, is_training)
                            with tf.variable_scope('ud3'):
                                c1 = lrelu(deconv_layer(x3, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #c1 = batch_normalize(c1, is_training)
                            sum = tf.concat([a1,b1,c1],3)
                            #sum = batch_normalize(sum, is_training)
                            with tf.variable_scope('ud4'):
                                x1 = lrelu(deconv_layer(tf.concat([sum,x1],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x1 = batch_normalize(x1, is_training)
                            with tf.variable_scope('ud5'):
                                x2 = lrelu(deconv_layer(tf.concat([sum,x2],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x2 = batch_normalize(x2, is_training)
                            with tf.variable_scope('ud6'):
                                x3 = lrelu(deconv_layer(tf.concat([sum,x3],3), [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                                #x3 = batch_normalize(x3, is_training)
                    with tf.variable_scope('ud7'):
                        block_out = lrelu(deconv_layer(tf.concat([x1, x2, x3],3), [3, 3, self.channels, self.channels*3], [self.batch_size, self.image_size, self.image_size, self.channels], 1))
                    #x = x1+x2+x3+x
                    x_f+=block_out
            #res_in = x_f
            # mask
            with tf.variable_scope('conv_m3'):
                x_mask = deconv_layer(
                    res_in, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1)
                x_mask = lrelu(x_mask)
            with tf.variable_scope('conv_m4'):# res_in
                x_mask = deconv_layer(
                    x_mask, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels], 1)
                x_mask = lrelu(x_mask)
            with tf.variable_scope('conv_m5'):
                x_mask = deconv_layer(
                    x_mask, [1, 1, self.channels*4, self.channels], [self.batch_size, self.image_size, self.image_size, self.channels*4], 1)
                x_mask = lrelu(x_mask)
            with tf.variable_scope('conv_m6'):
                x_mask = deconv_layer(
                    x_mask, [1, 1, self.channels, self.channels*4], [self.batch_size, self.image_size, self.image_size, self.channels], 1)
                x_mask = lrelu(x_mask)
            frame_mask = tf.nn.sigmoid(x_mask)
            x_frame = frame_mask*x_f + x_f
  
            with tf.variable_scope('conv_d3'):
                x_frame = deconv_layer(
                    x_frame, [3, 3, self.channels, self.channels], [self.batch_size, self.image_size*2, self.image_size*2, self.channels], 2)
                #x_frame = pixel_shuffle_layerg(x_frame, 2, self.channels//2)
                x_frame = lrelu(x_frame)
             
            #x_de = x_d + x_frame
            with tf.variable_scope('fusion2'):
                x_frame = deconv_layer(
                    x_frame, [3, 3, 1, self.channels], [self.batch_size, self.image_size*2, self.image_size*2, 1], 1)
                #x_de = lrelu(x_de)

            x_DN = x_frame + x_dn_base - x_fa
            frame_e = x_frame-x_fa
        self.g_variables = tf.get_collection(
            tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        return frame_e, x_dn_base, x_DN

    def downscale(self, x):
        K = 4
        arr = np.zeros([K, K, 3, 3])
        arr[:, :, 0, 0] = 1.0 / K ** 2
        arr[:, :, 1, 1] = 1.0 / K ** 2
        arr[:, :, 2, 2] = 1.0 / K ** 2
        weight = tf.constant(arr, dtype=tf.float32)
        downscaled = tf.nn.conv2d(
            x, weight, strides=[1, K, K, 1], padding='SAME')
        return downscaled
    
    def Laplacian_single(self, x):
        weight=tf.constant([[-1.0], [8.0], [-1.0],
                                  [-1.0], [8.0], [-1.0],
                                  [-1.0], [8.0], [-1.0]],
                                 shape=[3, 3, 1, 1])
        frame=tf.nn.conv2d(x,weight,[1,1,1,1],padding='SAME')
        #frame = tf.cast(((frame - tf.reduce_min(frame)) / (tf.reduce_max(frame) - tf.reduce_min(frame))) * 255, tf.uint8)
        return frame
        
    def sobel(self, x):
        weight=tf.constant([[[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]],
                            [[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]],
                            [[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]]],
                                 shape=[3, 3, 3, 3])
        frame=tf.nn.conv2d(x,weight,[1,1,1,1],padding='SAME')
        frame = tf.cast(((frame - tf.reduce_min(frame)) / (tf.reduce_max(frame) - tf.reduce_min(frame)))*2.0-1, tf.float32)
        #frame = tf.cast(((frame - tf.reduce_min(frame)) / (tf.reduce_max(frame) - tf.reduce_min(frame))) * 255, tf.uint8)
        return frame
        
    def Laplacian(self, x):
        weight=tf.constant([
        [[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]],[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]],[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]]],
        [[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]],[[8.,0.,0.],[0.,8.,0.],[0.,0.,8.]],[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]]],
        [[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]],[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]],[[-1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]]]
        ])
        frame=tf.nn.conv2d(x,weight,[1,1,1,1],padding='SAME')
        #frame = tf.cast(((frame - tf.reduce_min(frame)) / (tf.reduce_max(frame) - tf.reduce_min(frame))) * 255, tf.uint8)
        return frame
    
    def sobelg(self, x):
        weightx=tf.constant([[[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]],
                            [[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]],
                            [[-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0],
                                  [-2.0, -2.0, -2.0], [0, 0, 0], [2.0, 2.0, 2.0],
                                  [-1.0, -1.0, -1.0], [0, 0, 0], [1.0, 1.0, 1.0]]],
                                 shape=[3, 3, 3, 3])
        framex=tf.nn.conv2d(x,weightx,[1,1,1,1],padding='SAME')
        weighty=tf.constant([[[-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0],
                                  [0.0, 0.0, 0.0], [0, 0, 0], [0.0, 0.0, 0.0],
                                  [1.0, 2.0, 1.0], [1.0, 2.0, 1.0], [1.0, 2.0, 1.0]],
                             [[-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0],
                                  [0.0, 0.0, 0.0], [0, 0, 0], [0.0, 0.0, 0.0],
                                  [1.0, 2.0, 1.0], [1.0, 2.0, 1.0], [1.0, 2.0, 1.0]],
                             [[-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0], [-1.0, -2.0, -1.0],
                                  [0.0, 0.0, 0.0], [0, 0, 0], [0.0, 0.0, 0.0],
                                  [1.0, 2.0, 1.0], [1.0, 2.0, 1.0], [1.0, 2.0, 1.0]]],
                                 shape=[3, 3, 3, 3])
        framey=tf.nn.conv2d(x,weighty,[1,1,1,1],padding='SAME')    
        frame = tf.sqrt(framex*framex + framey*framey)        
        #frame=lrelu(tf.nn.conv2d(x,weight,[1,1,1,1],padding='SAME'))
        #frame = tf.cast(((frame - tf.reduce_min(frame)) / (tf.reduce_max(frame) - tf.reduce_min(frame))) * 255, tf.uint8)
        return frame
        
    def inference_losses(self, x, base_dn, imitation_dn):
        
        def inference_content_loss_sr(frame_hr, frame_sr):
            content_base_loss = tf.reduce_mean(tf.sqrt((frame_hr - frame_sr) ** 2+(1e-3)**2))
            return content_base_loss

        content_mse_loss_BASE = inference_content_loss_sr(x, base_dn)
        content_mse_loss_DN = inference_content_loss_sr(x, imitation_dn)
        SSIM_LOSS = tf_ssim(x, imitation_dn)

        all_loss = 1.5*content_mse_loss_BASE + 1*content_mse_loss_DN - 0.2*SSIM_LOSS
        return (all_loss, SSIM_LOSS)

